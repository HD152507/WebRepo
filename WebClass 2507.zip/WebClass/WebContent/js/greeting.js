//jsalert("안녕하세요");

if (value == "한국") {
  alert("안녕하세요");
}
else if (value == "미국") {
  alert("Hello");
}
else if (value == "중국") {
    alert("니하오");
}
